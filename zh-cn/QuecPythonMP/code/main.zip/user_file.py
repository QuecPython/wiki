import uos


def Qprint():
    print('Hello World !')


def Qlistdir():
    print(uos.listdir('/usr'))
