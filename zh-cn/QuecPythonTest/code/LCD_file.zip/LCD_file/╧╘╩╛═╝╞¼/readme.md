使用方法步骤：
1、将240*240的显示屏正确接到模块上；
2、将本目录的3个py文件（st7789v.py、image.py、example_display_image.py）拷贝到模块的usr目录下；
3、进入模块的命令行，执行如下指令即可看到显示屏显示图片：
>>> import example
>>> example.exec('usr/example_display_image.py')
