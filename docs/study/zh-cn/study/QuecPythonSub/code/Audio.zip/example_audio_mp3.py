# -*- coding: UTF-8 -*-

import utime as time
import audio
from machine import Pin


def example_audio_mp3():
    '''
    外接喇叭播放录音文件，参数选择0
    '''
    aud = audio.Audio(0)
    '''
    使能外接喇叭播放
    '''
    Pin(Pin.GPIO11, Pin.OUT, Pin.PULL_PD, 1)
    # U: 表示用户目录， GUI下载工具会将文件下载到 /usr 文件下
    aud.play(2, 1, "U:/example_maonv.mp3")
    pass


if __name__ == "__main__":
    example_audio_mp3()
