# -*- coding: UTF-8 -*-

import utime as time
import urandom as random
import audio
from machine import Pin

exited = True


def audio_cb(event):
    global exited
    # 7表示播放完毕
    if event == 7:
        exited = False
        print('audio-play finish.')


def example_audio_mp3():
    global exited
    '''
    外接喇叭播放录音文件，参数选择0
    '''
    aud = audio.Audio(0)
    '''
    使能外接喇叭播放
    '''
    Pin(Pin.GPIO11, Pin.OUT, Pin.PULL_PD, 1)
    aud.setCallback(audio_cb)
    for i in range(3):  # 演示3次
        # U: 表示用户目录， GUI下载工具会将文件下载到 /usr 文件下
        aud.play(2, 1, "U:/example_maonv.mp3")
        while exited:
            aud.setVolume(random.randint(6, 11))
            time.sleep_ms(500)
        exited = True

    print("example_audio_mp3 has exit")


if __name__ == "__main__":
    example_audio_mp3()
