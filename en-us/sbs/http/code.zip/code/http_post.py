import request
import ujson
url = "http://httpbin.org/post"
data = {"key1": "value1", "key2": "value2", "key3": "value3"}
# POST 请求
response = request.post(url, data=ujson.dumps(data))
print(response.text)