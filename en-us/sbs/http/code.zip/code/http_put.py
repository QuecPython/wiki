import request
url = "http://httpbin.org/put"
# PUT 请求
response = request.put(url)
print(response.text)