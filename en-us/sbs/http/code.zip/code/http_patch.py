import request
url = "http://httpbin.org/patch"
# PATCH 请求
response = request.patch(url)
print(response.text)