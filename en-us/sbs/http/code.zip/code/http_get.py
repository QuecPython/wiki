import request
url = "http://httpbin.org/get"
# GET 请求
response = request.get(url)
print(response.text)