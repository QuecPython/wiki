import request
url = "http://httpbin.org/delete"
# DELETE 请求
response = request.delete(url)
print(response.text)