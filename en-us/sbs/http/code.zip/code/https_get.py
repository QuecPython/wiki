import request
url = "https://myssl.com"
# HTTPS 请求
response = request.get(url)
print(response.text)